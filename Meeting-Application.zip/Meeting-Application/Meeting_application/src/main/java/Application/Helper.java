package Application;


import Application.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Soojl
 */
public class Helper {
    public static String email;
    public static String userId;
    public static String password;
    public static String user="soojal";
    public static int pass=12345;

    // Method to return a value
    public static String getemail() {
        return email;
}
    
    public static String getuserId() {
        return userId;
}
    
    public static String password() {
        return password;
}
}
